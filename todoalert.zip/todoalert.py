import xmlrpc.client
from datetime import datetime, timedelta
import requests
import json
import re
import hashlib
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import schedule
import time
import threading

# Odoo connection parameters
url = 'http://84.247.136.24:8069'
db = 'mydb'
username = 'admin'
password = '79NM46eRqDv)w^q^'

# Supabase connection parameters - YOUR RFP DATABASE
SUPABASE_URL = 'https://noyhwradxrqojexlfvtw.supabase.co'
SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im5veWh3cmFkeHJxb2pleGxmdnR3Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDY2OTYzODYsImV4cCI6MjA2MjI3MjM4Nn0.aDYfXWsa_Xe9X3eh-SgVB9HH79fTSfo-SWeRMp0otPU'

# Email configuration
EMAIL_RECIPIENT = 'saicharanrajampeta78@gmail.com'
EMAIL_SUBJECT = 'RFP Opportunities Due Within 3 Days'
SMTP_SERVER = 'smtp.gmail.com'
SMTP_PORT = 587
EMAIL_SENDER = 'saicharanrajampeta78@gmail.com'  # Replace with your email
EMAIL_PASSWORD = 'nxyk gkwc hqjo iwlv'   # Replace with your app password

# Date parser (added extra formats and comma tolerance)
def parse_event_date(event_date_str):
    if not event_date_str:
        return None
    s = event_date_str.strip().replace('  ', ' ')
    fmts = [
        '%a, %b %d %Y, %H:%M',      # Wed, Oct 15 2025, 00:00
        '%a, %b %d, %Y, %H:%M',     # Wed, Oct 15, 2025, 00:00
        '%Y-%m-%d',
        '%Y-%m-%d %H:%M:%S',
        '%b %d %Y',
        '%m/%d/%Y',
        '%d/%m/%Y',
        '%Y/%m/%d',
        '%a, %d %b %Y %H:%M:%S',
    ]
    for f in fmts:
        try:
            return datetime.strptime(s, f)
        except:
            continue
    return None

def create_unique_rfp_identifier(subject, event_date):
    sub = (subject or '').strip().lower()
    d   = str(event_date).strip().lower()
    return hashlib.md5(f"{sub}_{d}".encode()).hexdigest()[:16]
# ------------------------------------------------------------------

def fetch_rfp_data_from_supabase():
    print("🔗 Connecting to Supabase database...")
    today = datetime.now().date()
    print(f"📅 Today's date: {today}")

    try:
        # ✅ Correct Supabase REST endpoint
        supabase_api_url = f"{SUPABASE_URL}/rest/v1/rfpproject"

        headers = {
            "apikey": SUPABASE_KEY,
            "Authorization": f"Bearer {SUPABASE_KEY}",
            "Accept": "application/json",              # ✅ required for output
            "Content-Type": "application/json",
            "Range": "0-9999"                          # ✅ fetch all rows
        }

        # ✅ No Prefer header (not needed for GET)
        params = {"select": "*"}                      # fetch all columns

        response = requests.get(supabase_api_url, headers=headers, params=params)

        if response.status_code != 200:
            print(f"❌ Supabase Error {response.status_code}: {response.text[:500]}")
            return []

        rfp_data = response.json()
        print(f"✅ Retrieved {len(rfp_data)} records from Supabase.")

        filtered, seen = [], set()
        for rfp in rfp_data:
            subject = rfp.get("subject") or rfp.get("title") or rfp.get("bject") or ""
            event_date_str = rfp.get("event_date")

            parsed_date = parse_event_date(event_date_str)
            if not parsed_date:
                continue

            days_until = (parsed_date.date() - today).days
            # ✅ include all future RFPs up to 1 year + past 30 days
            if -30 <= days_until <= 365:
                uid = create_unique_rfp_identifier(subject, parsed_date)
                if uid not in seen:
                    seen.add(uid)
                    rfp["unique_id"] = uid
                    rfp["parsed_event_date"] = parsed_date
                    rfp["days_until_due"] = days_until
                    rfp["subject"] = subject
                    filtered.append(rfp)

        print(f"📊 Filtered {len(filtered)} valid RFPs for Odoo import.")
        return filtered

    except Exception as e:
        print(f"❌ Error fetching data from Supabase: {e}")
        return []

def parse_event_date(event_date_str):
    if not event_date_str:
        return None
    event_date_str = event_date_str.strip()
    date_formats = [
        '%a, %b %d %Y, %H:%M',  # Thu, Oct 16 2025, 00:00
        '%Y-%m-%d',             # 2025-10-16
        '%Y-%m-%d %H:%M:%S',    # 2025-10-16 00:00:00
        '%m/%d/%Y',             # 10/16/2025
        '%d/%m/%Y',             # 16/10/2025
        '%Y/%m/%d',             # 2025/10/16
        '%Y-%m-%dT%H:%M:%S.%fZ', # 2025-10-16T00:00:00.000Z
        '%Y-%m-%dT%H:%M:%S%z',   # 2025-10-16T00:00:00+00:00
        '%b %d %Y',              # Oct 16 2025
        '%a, %d %b %Y %H:%M:%S', # Fri, 17 Oct 2025 00:00:00
    ]
    for fmt in date_formats:
        try:
            return datetime.strptime(event_date_str, fmt)
        except Exception:
            continue
    return None


def create_unique_rfp_identifier(subject, event_date):
    clean_subject = re.sub(r'\s*Capture this Bid\s*$', '', subject or '', flags=re.IGNORECASE).strip().lower()
    clean_date = str(event_date).strip().lower()
    return hashlib.md5(f"{clean_subject}_{clean_date}".encode()).hexdigest()[:16]


def fetch_rfp_data_from_supabase():
    print("🔗 Connecting to Supabase database...")
    try:
        today = datetime.now().date()
        print(f"📅 Today's date: {today}")
        supabase_api_url = f"{SUPABASE_URL}/rest/v1/rfpproject"
        headers = {
            'apikey': SUPABASE_KEY,
            'Authorization': f'Bearer {SUPABASE_KEY}',
            'Content-Type': 'application/json',
            'Prefer': 'return=representation'
        }
        params = {'select': '*', 'limit': 1000}
        response = requests.get(supabase_api_url, headers=headers, params=params)
        if response.status_code != 200:
            print(f"❌ Supabase Error {response.status_code}: {response.text[:500]}")
            return []

        rfp_data = response.json()
        print(f"✅ Retrieved {len(rfp_data)} records from Supabase.")

        filtered = []
        seen = set()
        for rfp in rfp_data:
            subject = rfp.get('subject') or rfp.get('title') or rfp.get('bject') or ''
            event_date_str = rfp.get('event_date')
            parsed_date = parse_event_date(event_date_str)
            if not parsed_date:
                continue

            days_until = (parsed_date.date() - today).days
            # FIX 2: Include all due and upcoming (±60 days)
            if -5 <= days_until <= 60:
                uid = create_unique_rfp_identifier(subject, parsed_date)
                if uid not in seen:
                    seen.add(uid)
                    rfp['unique_id'] = uid
                    rfp['parsed_event_date'] = parsed_date
                    rfp['days_until_due'] = days_until
                    rfp['subject'] = subject
                    filtered.append(rfp)
        print(f"📊 Filtered {len(filtered)} valid RFPs for Odoo import.")
        return filtered
    except Exception as e:
        print("❌ Error fetching data from Supabase:", e)
        return []


def create_unique_rfp_identifier(subject, event_date):
    """Create a unique identifier for RFP to detect duplicates"""
    # Clean subject and remove "Capture this Bid"
    clean_subject = clean_text(subject)
    clean_subject = re.sub(r'\s*Capture this Bid\s*$', '', clean_subject, flags=re.IGNORECASE)
    clean_subject = clean_subject.strip()

    # Normalize the date string
    clean_date = str(event_date).strip()

    # Create hash from subject and date
    identifier_string = f"{clean_subject}_{clean_date}".lower()
    return hashlib.md5(identifier_string.encode()).hexdigest()[:16]

def determine_priority(days_until_due):
    """Determine priority based on days until due"""
    if days_until_due == 0:
        return "urgent"
    elif days_until_due <= 3:
        return "urgent"
    elif days_until_due <= 7:
        return "high"
    elif days_until_due <= 14:
        return "medium"
    else:
        return "low"

# Connect to Odoo server
print("🔗 Connecting to Odoo server...")
common = xmlrpc.client.ServerProxy(f"{url}/xmlrpc/2/common")
uid = common.authenticate(db, username, password, {})

if uid:
    print("✅ Authentication successful. User ID:", uid)
else:
    print("❌ Authentication failed.")
    exit()

# Connect to Odoo object endpoint
models = xmlrpc.client.ServerProxy(f"{url}/xmlrpc/2/object")

# Priority mapping for Odoo
priority_mapping = {
    "low": "0",
    "medium": "1",
    "high": "2",
    "urgent": "3"
}

def get_available_fields(model_name):
    """Get available fields for a model to avoid field errors"""
    try:
        fields = models.execute_kw(
            db, uid, password,
            model_name, 'fields_get',
            [], {'attributes': ['string', 'help', 'type']}
        )
        return list(fields.keys())
    except Exception as e:
        print(f"Error getting fields for {model_name}: {e}")
        return []

def clean_text(text):
    """Clean text to remove problematic characters"""
    if not text:
        return ""

    # Remove or replace problematic characters
    text = str(text)
    # Remove control characters and non-printable characters
    text = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f]', '', text)
    # Replace smart quotes and dashes
    text = text.replace('"', '"').replace('"', '"')
    text = text.replace(''', "'").replace(''', "'")
    text = text.replace('–', '-').replace('—', '-')
    # Remove extra whitespace
    text = ' '.join(text.split())
    return text

def create_safe_task_name(subject):
    """Create a safe task name that won't cause Odoo errors"""
    # Clean the subject first
    safe_subject = clean_text(subject)

    # Remove "Capture this Bid" suffix if present
    safe_subject = re.sub(r'\s*Capture this Bid\s*$', '', safe_subject, flags=re.IGNORECASE)
    safe_subject = safe_subject.strip()

    # Limit to 100 characters to avoid database field length issues
    if len(safe_subject) > 100:
        safe_subject = safe_subject[:97] + "..."

    return f"RFP: {safe_subject}"

def create_safe_description(rfp, days_until_due, priority):
    """Create a safe description that won't cause Odoo errors"""
    subject = clean_text(rfp.get('subject', 'No Subject'))
    event_date_str = rfp.get('event_date', 'No Date')
    unique_id = rfp.get('unique_id', 'No ID')

    # Remove "Capture this Bid" from subject in description
    subject = re.sub(r'\s*Capture this Bid\s*$', '', subject, flags=re.IGNORECASE)
    subject = subject.strip()

    # Add special marker for due today tasks
    due_today_marker = "\n🚨 DUE TODAY - URGENT ACTION REQUIRED!" if days_until_due == 0 else ""

    description = f"""RFP DEADLINE ALERT{due_today_marker}

Subject: {subject}
Due Date: {event_date_str}
Days Until Due: {days_until_due} days
Priority: {priority.upper()}

ACTION REQUIRED: Prepare and submit proposal response before deadline.

Unique ID: {unique_id}
Source: Supabase Database
Created: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"""

    return clean_text(description)

def get_existing_rfp_tasks_comprehensive():
    """Get all existing RFP tasks with comprehensive duplicate detection"""
    try:
        existing_tasks = models.execute_kw(
            db, uid, password,
            'project.task', 'search_read',
            [[['name', 'ilike', 'RFP:']]],
            {'fields': ['name', 'description', 'id', 'date_deadline']}
        )

        existing_identifiers = set()
        existing_task_info = {}
        existing_name_date_pairs = set()

        for task in existing_tasks:
            task_id = task['id']
            task_name = task.get('name', '')
            task_description = task.get('description', '')
            task_deadline = task.get('date_deadline', '')

            # Method 1: Extract unique identifier from description if present
            if 'Unique ID:' in task_description:
                try:
                    unique_id = task_description.split('Unique ID:')[1].split('\n')[0].strip()
                    existing_identifiers.add(unique_id)
                    existing_task_info[unique_id] = {
                        'id': task_id,
                        'name': task_name
                    }
                except:
                    pass

            # Method 2: Create name-date pair for additional duplicate detection
            name_clean = re.sub(r'^RFP:\s*', '', task_name).strip().lower()
            date_clean = task_deadline.split(' ')[0] if task_deadline else 'no-date'
            name_date_pair = f"{name_clean}|{date_clean}"
            existing_name_date_pairs.add(name_date_pair)

        print(f"📋 Found {len(existing_identifiers)} existing RFP tasks with unique IDs")
        print(f"📋 Found {len(existing_name_date_pairs)} existing name-date pairs")
        return existing_identifiers, existing_task_info, existing_name_date_pairs
    except Exception as e:
        print(f"⚠️  Error getting existing tasks: {e}")
        return set(), {}, set()

def check_task_duplicate(subject, event_date, unique_id, existing_identifiers, existing_name_date_pairs):
    """Check if task is duplicate using multiple methods"""
    # Method 1: Check unique ID
    if unique_id in existing_identifiers:
        return True, "Unique ID match"

    # Method 2: Check name-date pair
    clean_subject = clean_text(subject)
    clean_subject = re.sub(r'\s*Capture this Bid\s*$', '', clean_subject, flags=re.IGNORECASE)
    clean_subject = clean_subject.strip().lower()

    # Parse the date for comparison
    try:
        event_date_parsed = None
        date_formats = [
            '%a, %b %d %Y, %H:%M',  # Thu, Oct 16 2025, 00:00
            '%Y-%m-%d',             # 2025-10-16
            '%Y-%m-%d %H:%M:%S',    # 2025-10-16 00:00:00
            '%m/%d/%Y',             # 10/16/2025
            '%d/%m/%Y',             # 16/10/2025
            '%Y/%m/%d',             # 2025/10/16
        ]

        for date_format in date_formats:
            try:
                event_date_parsed = datetime.strptime(event_date, date_format)
                break
            except ValueError:
                continue

        if event_date_parsed:
            date_str = event_date_parsed.strftime('%Y-%m-%d')
            name_date_pair = f"{clean_subject}|{date_str}"
            if name_date_pair in existing_name_date_pairs:
                return True, "Name-Date pair match"
    except:
        pass

    return False, "No duplicate found"

def format_date_for_todo_fixed(event_date, days_until_due):
    """Format date properly for Odoo To-Do"""
    try:
        # Use actual current date
        today = datetime.now().date()

        # For tasks due today, use today's date
        if days_until_due == 0:
            return today.strftime('%Y-%m-%d')
        else:
            # For future tasks, use the actual event date
            if isinstance(event_date, datetime):
                return event_date.strftime('%Y-%m-%d')
            else:
                # Parse the event date string
                date_formats = [
                    '%a, %b %d %Y, %H:%M',
                    '%Y-%m-%d',
                    '%Y-%m-%d %H:%M:%S',
                    '%m/%d/%Y',
                    '%d/%m/%Y',
                    '%Y/%m/%d',
                ]

                for date_format in date_formats:
                    try:
                        parsed_date = datetime.strptime(str(event_date), date_format)
                        return parsed_date.strftime('%Y-%m-%d')
                    except ValueError:
                        continue

                # If all parsing fails, use the string as-is
                date_str = str(event_date)
                if re.match(r'\d{4}-\d{2}-\d{2}', date_str):
                    return date_str[:10]

                raise ValueError(f"Unable to parse date: {event_date}")

    except Exception as e:
        print(f"⚠️  Error formatting date: {e}")
        return datetime.now().strftime('%Y-%m-%d')

def get_default_user():
    """Get the default user (admin) for task assignment"""
    try:
        user_info = models.execute_kw(
            db, uid, password,
            'res.users', 'read',
            [uid],
            {'fields': ['id', 'name']}
        )
        if user_info:
            print(f"👤 Using user: {user_info[0]['name']} (ID: {user_info[0]['id']})")
            return user_info[0]['id']
    except Exception as e:
        print(f"⚠️  Error getting user info: {e}")
    return uid

def create_rfp_tasks_from_supabase():
    """Create RFP tasks in Odoo from Supabase data"""

    print("\n" + "="*80)
    print("Creating RFP Tasks from Supabase Database")
    print("="*80)

    # Fetch RFP data from Supabase
    supabase_rfp_data = fetch_rfp_data_from_supabase()

    if not supabase_rfp_data:
        print("❌ No RFP data found in Supabase. Exiting...")
        return []

    # Check available fields
    available_fields = get_available_fields('project.task')
    print(f"Available fields in project.task: {len(available_fields)} fields found")
    print()

    # Get default user for assignment
    default_user = get_default_user()

    # Get existing RFP tasks with comprehensive duplicate detection
    existing_identifiers, existing_task_info, existing_name_date_pairs = get_existing_rfp_tasks_comprehensive()

    created_tasks = []
    failed_tasks = []
    skipped_tasks = []

    print(f"📊 Processing {len(supabase_rfp_data)} RFP records from Supabase...")
    print()

    # Separate today's tasks and future tasks
    today_tasks = [rfp for rfp in supabase_rfp_data if rfp.get('days_until_due', 999) == 0]
    future_tasks = [rfp for rfp in supabase_rfp_data if rfp.get('days_until_due', 999) > 0]

    print(f"🚨 Tasks due TODAY: {len(today_tasks)}")
    print(f"📅 Future tasks: {len(future_tasks)}")
    print()

    # Process today's tasks first
    all_tasks = today_tasks + future_tasks

    for i, rfp in enumerate(all_tasks, 1):
        subject = rfp.get('subject', 'No Subject')
        event_date_str = rfp.get('event_date', '')
        days_until_due = rfp.get('days_until_due', 0)
        unique_id = rfp.get('unique_id', '')

        if not event_date_str:
            print(f"⚠️  Skipping RFP {i}: No event date found")
            continue

        # Enhanced duplicate checking
        is_duplicate, duplicate_reason = check_task_duplicate(
            subject, event_date_str, unique_id,
            existing_identifiers, existing_name_date_pairs
        )

        if is_duplicate:
            print(f"⚠️  Skipping duplicate RFP {i}: {subject[:50]}...")
            print(f"     Reason: {duplicate_reason}")
            skipped_tasks.append({'subject': subject, 'reason': duplicate_reason, 'unique_id': unique_id})
            continue

        print(f"🔄 Processing RFP {i}/{len(all_tasks)}: {subject[:50]}...")

        priority = determine_priority(days_until_due)

        print(f"   📅 Event Date: {event_date_str}")
        print(f"   ⏰ Days Until Due: {days_until_due}")
        print(f"   🎯 Priority: {priority.upper()}")
        if days_until_due == 0:
            print(f"   🚨 DUE TODAY!")

        # Use parsed date if available
        if 'parsed_event_date' in rfp:
            event_date = rfp['parsed_event_date']
        else:
            try:
                # Parse date using multiple formats
                event_date = None
                date_formats = [
                    '%a, %b %d %Y, %H:%M',
                    '%Y-%m-%d',
                    '%Y-%m-%d %H:%M:%S',
                    '%m/%d/%Y',
                    '%d/%m/%Y',
                    '%Y/%m/%d',
                ]

                for date_format in date_formats:
                    try:
                        event_date = datetime.strptime(event_date_str, date_format)
                        break
                    except ValueError:
                        continue

                if event_date is None:
                    raise ValueError(f"Unable to parse date format: {event_date_str}")

            except Exception as e:
                print(f"⚠️  Error parsing date for {subject}: {e}")
                failed_tasks.append({'subject': subject, 'error': f'Date parsing error: {e}'})
                continue

        try:
            # Format date for Odoo
            due_date_formatted = format_date_for_todo_fixed(event_date, days_until_due)

            # Create enhanced description with unique identifier
            enhanced_description = create_safe_description(rfp, days_until_due, priority)

            # Task data without kanban_state field
            task_data = {
                'name': create_safe_task_name(subject),
                'description': enhanced_description,
                'date_deadline': due_date_formatted,
                'priority': priority_mapping.get(priority, '1'),
                'active': True,
                'user_ids': [(6, 0, [default_user])],
            }

            # Create the task
            try:
                task_id = models.execute_kw(
                    db, uid, password,
                    'project.task', 'create',
                    [task_data]
                )

                if task_id:
                    created_tasks.append({
                        'id': task_id,
                        'name': create_safe_task_name(subject),
                        'subject': subject,
                        'event_date': event_date_str,
                        'due_date': due_date_formatted,
                        'priority': priority,
                        'days_until_due': days_until_due,
                        'unique_id': unique_id
                    })

                    print(f"✅ Task {i}/{len(all_tasks)} Created Successfully:")
                    print(f"   Task ID: {task_id}")
                    print(f"   Subject: {subject[:50]}...")
                    print(f"   Due Date: {due_date_formatted}")
                    print(f"   Days Until Due: {days_until_due} days")
                    print(f"   Priority: {priority.upper()}")
                    if days_until_due == 0:
                        print(f"   🚨 DUE TODAY!")
                    print()

                    # Update tracking sets
                    existing_identifiers.add(unique_id)
                    clean_subject = clean_text(subject)
                    clean_subject = re.sub(r'\s*Capture this Bid\s*$', '', clean_subject, flags=re.IGNORECASE)
                    name_date_pair = f"{clean_subject.strip().lower()}|{due_date_formatted}"
                    existing_name_date_pairs.add(name_date_pair)

            except Exception as create_error:
                error_msg = str(create_error)
                print(f"❌ Error creating task for {subject[:50]}...")
                print(f"   Error: {error_msg[:200]}...")
                failed_tasks.append({'subject': subject, 'error': error_msg})
                print()
                continue

        except Exception as e:
            error_msg = str(e)
            print(f"❌ Error processing task for {subject[:50]}...")
            print(f"   Error: {error_msg[:100]}...")
            failed_tasks.append({'subject': subject, 'error': error_msg})
            print()
            continue

    # Print summary of skipped and failed tasks
    if skipped_tasks:
        print(f"\n⚠️  {len(skipped_tasks)} tasks skipped (duplicates):")
        for skipped in skipped_tasks[:10]:
            print(f"   • {skipped['subject'][:50]}... - {skipped['reason']}")
        if len(skipped_tasks) > 10:
            print(f"   ... and {len(skipped_tasks) - 10} more duplicates")
        print()

    if failed_tasks:
        print(f"\n⚠️  {len(failed_tasks)} tasks failed to create:")
        for failed in failed_tasks[:5]:
            print(f"   • {failed['subject'][:50]}... - {failed['error'][:50]}...")
        if len(failed_tasks) > 5:
            print(f"   ... and {len(failed_tasks) - 5} more failures")
        print()

    return created_tasks

def verify_tasks_in_odoo():
    """Verify that tasks were actually created and are visible in Odoo To-Do"""
    try:
        # Removed kanban_state field that doesn't exist
        rfp_tasks = models.execute_kw(
            db, uid, password,
            'project.task', 'search_read',
            [[['name', 'ilike', 'RFP:']]],
            {'fields': ['name', 'date_deadline', 'priority', 'description', 'stage_id', 'user_ids']}
        )

        print("\n" + "="*80)
        print("VERIFICATION: RFP Tasks in Odoo To-Do")
        print("="*80)

        if rfp_tasks:
            print(f"✅ Found {len(rfp_tasks)} RFP tasks in Odoo database:")
            print()

            # Sort by deadline
            rfp_tasks.sort(key=lambda x: x.get('date_deadline', '9999-12-31'))

            # Count tasks by urgency - use actual current date
            today = datetime.now().date()
            today_count = 0
            tomorrow_count = 0
            urgent_count = 0

            print("📋 TASK DETAILS:")
            for i, task in enumerate(rfp_tasks, 1):
                deadline_str = task.get('date_deadline', '')
                days_until = 999

                if deadline_str:
                    try:
                        if ' ' in deadline_str:
                            deadline_date = datetime.strptime(deadline_str, '%Y-%m-%d %H:%M:%S').date()
                        else:
                            deadline_date = datetime.strptime(deadline_str, '%Y-%m-%d').date()

                        days_until = (deadline_date - today).days
                        if days_until == 0:
                            today_count += 1
                        elif days_until == 1:
                            tomorrow_count += 1
                        elif days_until <= 3:
                            urgent_count += 1
                    except Exception as date_error:
                        print(f"   ⚠️  Date parsing error for task: {date_error}")

                priority_text = {
                    '0': 'LOW',
                    '1': 'MEDIUM',
                    '2': 'HIGH',
                    '3': 'URGENT'
                }.get(task.get('priority', '1'), 'MEDIUM')

                due_today_indicator = " 🚨 DUE TODAY!" if days_until == 0 else ""
                due_tomorrow_indicator = " 📅 TOMORROW!" if days_until == 1 else ""

                print(f"{i:2d}. {task['name'][:55]}...{due_today_indicator}{due_tomorrow_indicator}")
                print(f"    Due: {task.get('date_deadline', 'Not set')} ({days_until} days)")
                print(f"    Priority: {priority_text}")
                print()

            print(f"📊 SUMMARY:")
            print(f"   🚨 Due TODAY: {today_count} tasks")
            print(f"   📅 Due TOMORROW: {tomorrow_count} tasks")
            print(f"   ⚡ URGENT (1-3 days): {urgent_count} tasks")
            print(f"   📋 TOTAL: {len(rfp_tasks)} tasks")
            print()

            if today_count > 0:
                print(f"✅ {today_count} tasks are due TODAY!")
            else:
                print("ℹ️  No tasks due today found.")

            return True
        else:
            print("❌ No RFP tasks found in Odoo database!")
            return False

    except Exception as e:
        print(f"❌ Error verifying tasks in Odoo: {e}")
        return False

def display_summary(created_tasks):
    """Display summary of created tasks"""
    print("\n" + "="*80)
    print("RFP TASKS SUMMARY (FROM SUPABASE) - COMPLETELY FIXED")
    print("="*80)

    if not created_tasks:
        print("❌ No new tasks were created.")
        print("💡 This could mean:")
        print("   - All RFPs already exist in Odoo (duplicates prevented)")
        print("   - No RFPs are due in the next 60 days")
        print("   - Connection issues with Supabase or Odoo")
        return

    # Sort tasks by days until due
    created_tasks.sort(key=lambda x: x['days_until_due'])

    print(f"✅ Successfully created {len(created_tasks)} NEW RFP tasks from Supabase!")
    print()

    # Group by urgency
    today_due = [task for task in created_tasks if task['days_until_due'] == 0]
    tomorrow_due = [task for task in created_tasks if task['days_until_due'] == 1]
    urgent_tasks = [task for task in created_tasks if 2 <= task['days_until_due'] <= 7]
    this_month = [task for task in created_tasks if 7 < task['days_until_due'] <= 30]
    next_month = [task for task in created_tasks if 30 < task['days_until_due'] <= 60]

    if today_due:
        print("🚨 DUE TODAY:")
        for task in today_due:
            print(f"   • {task['subject'][:60]}...")
            print(f"     Due: {task['due_date']} (TODAY!)")
        print()

    if tomorrow_due:
        print("📅 DUE TOMORROW:")
        for task in tomorrow_due:
            print(f"   • {task['subject'][:60]}...")
            print(f"     Due: {task['due_date']} (TOMORROW)")
        print()

    if urgent_tasks:
        print("⚡ HIGH PRIORITY - Due within 7 days:")
        for task in urgent_tasks:
            print(f"   • {task['subject'][:60]}...")
            print(f"     Due: {task['due_date']} ({task['days_until_due']} days)")
        print()

    if this_month:
        print("📅 MEDIUM PRIORITY - Due within 30 days:")
        for task in this_month:
            print(f"   • {task['subject'][:60]}...")
            print(f"     Due: {task['due_date']} ({task['days_until_due']} days)")
        print()

    if next_month:
        print("📅 LOW PRIORITY - Due within 60 days:")
        for task in next_month:
            print(f"   • {task['subject'][:60]}...")
            print(f"     Due: {task['due_date']} ({task['days_until_due']} days)")
        print()

    print("="*80)
    print("🎯 HOW TO VIEW YOUR RFP TASKS IN ODOO TO-DO:")
    print()
    print("   1. Go to To-do (main menu)")
    print("   2. Click on 'To-dos' to see the filtered view")
    print("   3. Look at the 'Today' column on the right - it should show the count")
    print("   🚨 Tasks due TODAY should appear in the Today column with proper count")
    print("   ✅ FIXED: Today column will no longer be empty for due today tasks")
    print("   4. Use the calendar view icon to see all due dates visually")
    print("   💡 Tasks due today are marked with URGENT priority (3 stars)")
    print("   🔍 All RFP tasks start with 'RFP:' for easy identification")
    print("="*80)

# =============================================================================
# FIXED EMAIL NOTIFICATION FUNCTIONALITY - CORRECTED DATE LOGIC
# =============================================================================

def get_rfps_due_within_days(days=3):
    """Get all RFP tasks due within specified days from Odoo - FIXED DATE LOGIC"""
    try:
        today = datetime.now().date()
        end_date = today + timedelta(days=days)
        
        print(f"🔍 Searching for RFP tasks due between {today} and {end_date}")
        
        # Get all RFP tasks and filter by date range in Python
        all_rfp_tasks = models.execute_kw(
            db, uid, password,
            'project.task', 'search_read',
            [[['name', 'ilike', 'RFP:']]],
            {'fields': ['name', 'date_deadline', 'priority', 'description', 'user_ids']}
        )
        
        due_tasks = []
        
        for task in all_rfp_tasks:
            deadline = task.get('date_deadline')
            if deadline:
                # Handle different date formats
                deadline_date = None
                try:
                    # Try parsing as full datetime
                    if ' ' in deadline:
                        deadline_date = datetime.strptime(deadline, '%Y-%m-%d %H:%M:%S').date()
                    else:
                        # Try parsing as date only
                        deadline_date = datetime.strptime(deadline, '%Y-%m-%d').date()
                    
                    # FIXED: Include tasks from today to end_date (inclusive)
                    if today <= deadline_date <= end_date:
                        # Extract additional information from description if available
                        description = task.get('description', '')
                        subject = task['name'].replace('RFP: ', '').strip()
                        
                        # Try to extract agency, reference, contact from description
                        agency = "NOT AVAILABLE"
                        reference = "NOT AVAILABLE" 
                        contact = "NOT AVAILABLE"
                        online_link = "NOT AVAILABLE"
                        
                        # Extract information from description patterns
                        if 'Source:' in description:
                            agency = description.split('Source:')[1].split('\n')[0].strip()
                        if 'Unique ID:' in description:
                            reference = description.split('Unique ID:')[1].split('\n')[0].strip()
                        
                        days_until_due = (deadline_date - today).days
                        
                        due_tasks.append({
                            'subject': subject,
                            'online_link': online_link,
                            'due_date': deadline_date.strftime('%Y-%m-%d'),
                            'agency': agency,
                            'reference': reference,
                            'contact': contact,
                            'priority': task.get('priority', '1'),
                            'days_until_due': days_until_due,
                            'raw_deadline': deadline
                        })
                        
                except Exception as e:
                    print(f"⚠️  Date parsing error for task '{task['name']}': {e}")
                    print(f"   Raw deadline value: {deadline}")
                    continue
        
        # Sort by due date and days until due
        due_tasks.sort(key=lambda x: (x['due_date'], x['days_until_due']))
        
        print(f"✅ Found {len(due_tasks)} RFP tasks due within {days} days")
        
        # Debug: Print found tasks with detailed information
        if due_tasks:
            print("📋 RFP Tasks Due (Detailed):")
            for i, task in enumerate(due_tasks, 1):
                urgency = "🚨 TODAY" if task['days_until_due'] == 0 else f"{task['days_until_due']} days"
                print(f"   {i}. {task['subject']} - Due: {task['due_date']} ({urgency}) - Raw: {task['raw_deadline']}")
        else:
            print("ℹ️  No RFP tasks found within the date range")
            
        return due_tasks
        
    except Exception as e:
        print(f"❌ Error fetching RFP tasks: {e}")
        return []

def send_email_notification(due_tasks):
    """Send email notification with RFP tasks in table format - FIXED VERSION"""
    try:
        # Email configuration
        sender_email = EMAIL_SENDER
        sender_password = EMAIL_PASSWORD
        recipient_email = EMAIL_RECIPIENT
        
        # Create message
        msg = MIMEMultipart()
        msg['From'] = sender_email
        msg['To'] = recipient_email
        msg['Subject'] = EMAIL_SUBJECT
        
        # Email body
        today = datetime.now().strftime('%Y-%m-%d')
        current_time = datetime.now().strftime('%I:%M:%S %p')
        
        if due_tasks:
            # Create HTML email content with table structure
            html_content = f"""
            <html>
            <head>
                <style>
                    body {{ font-family: Arial, sans-serif; margin: 20px; background-color: #f5f5f5; }}
                    .container {{ max-width: 1200px; margin: 0 auto; background-color: white; padding: 20px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }}
                    .header {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 10px; margin-bottom: 20px; text-align: center; }}
                    .summary {{ background-color: #fff3cd; border-left: 4px solid #ffc107; padding: 15px; margin: 20px 0; border-radius: 5px; }}
                    table {{ width: 100%; border-collapse: collapse; margin: 20px 0; font-size: 14px; }}
                    th {{ background-color: #2c3e50; color: white; padding: 12px; text-align: left; border: 1px solid #34495e; }}
                    td {{ padding: 10px; border: 1px solid #ddd; }}
                    tr:nth-child(even) {{ background-color: #f8f9fa; }}
                    tr:hover {{ background-color: #e9ecef; }}
                    .due-today {{ background-color: #fff3cd !important; font-weight: bold; }}
                    .due-tomorrow {{ background-color: #d1ecf1 !important; }}
                    .subject-column {{ width: 25%; }}
                    .link-column {{ width: 20%; }}
                    .date-column {{ width: 12%; }}
                    .agency-column {{ width: 18%; }}
                    .reference-column {{ width: 15%; }}
                    .contact-column {{ width: 10%; }}
                    .footer {{ margin-top: 30px; padding-top: 20px; border-top: 1px solid #eee; color: #666; font-size: 12px; text-align: center; }}
                    .urgent-badge {{ background-color: #dc3545; color: white; padding: 3px 8px; border-radius: 12px; font-size: 11px; font-weight: bold; }}
                    .link {{ color: #007bff; text-decoration: none; }}
                    .link:hover {{ text-decoration: underline; }}
                    .days-badge {{ background-color: #6c757d; color: white; padding: 2px 6px; border-radius: 10px; font-size: 10px; margin-left: 5px; }}
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="header">
                        <h1>📋 RFP Opportunities Due Within 3 Days</h1>
                    </div>
                    
                    <div class="summary">
                        <h3>📊 Summary</h3>
                        <p>Total RFP Opportunities: <strong>{len(due_tasks)}</strong></p>
                        <p>Due Today: <strong>{len([task for task in due_tasks if task['days_until_due'] == 0])}</strong></p>
                        <p>Due Tomorrow: <strong>{len([task for task in due_tasks if task['days_until_due'] == 1])}</strong></p>
                        <p>Due in 2-3 Days: <strong>{len([task for task in due_tasks if task['days_until_due'] >= 2])}</strong></p>
                    </div>

                    <table>
                        <thead>
                            <tr>
                                <th class="subject-column">Subject</th>
                                <th class="link-column">Online Link</th>
                                <th class="date-column">Due Date</th>
                                <th class="agency-column">Agency</th>
                                <th class="reference-column">Reference</th>
                                <th class="contact-column">Contact</th>
                            </tr>
                        </thead>
                        <tbody>
            """
            
            for task in due_tasks:
                # Determine row class based on urgency
                row_class = ""
                if task['days_until_due'] == 0:
                    row_class = "due-today"
                elif task['days_until_due'] == 1:
                    row_class = "due-tomorrow"
                
                # Format online link
                online_link = task['online_link']
                if online_link != "NOT AVAILABLE" and online_link.startswith('http'):
                    link_display = f'<a href="{online_link}" class="link">View Opportunity</a>'
                else:
                    link_display = "NOT AVAILABLE"
                
                # Add urgency indicator to due date
                due_date_display = task['due_date']
                if task['days_until_due'] == 0:
                    due_date_display += ' <span class="urgent-badge">TODAY</span>'
                elif task['days_until_due'] == 1:
                    due_date_display += ' <span class="days-badge">TOMORROW</span>'
                else:
                    due_date_display += f' <span class="days-badge">{task["days_until_due"]} days</span>'
                
                html_content += f"""
                            <tr class="{row_class}">
                                <td class="subject-column"><strong>{task['subject']}</strong></td>
                                <td class="link-column">{link_display}</td>
                                <td class="date-column">{due_date_display}</td>
                                <td class="agency-column">{task['agency']}</td>
                                <td class="reference-column">{task['reference']}</td>
                                <td class="contact-column">{task['contact']}</td>
                            </tr>
                """
            
            html_content += f"""
                        </tbody>
                    </table>
                    
                    <div style="background-color: #e2e3e5; padding: 15px; border-radius: 5px; margin: 20px 0;">
                        <h3>💡 Action Required</h3>
                        <p>Please review these RFP opportunities and take appropriate action before their due dates.</p>
                        <p>Login to Odoo for detailed information and task management.</p>
                    </div>
                    
                    <div class="footer">
                        <p><strong>Last updated:</strong> {today}, {current_time} IST</p>
                        <p>This report is automatically generated by the RFP Monitoring System.</p>
                        <p><strong>Note:</strong> Tasks are shown for the next 3 days including today.</p>
                    </div>
                </div>
            </body>
            </html>
            """
        else:
            html_content = f"""
            <html>
            <head>
                <style>
                    body {{ font-family: Arial, sans-serif; margin: 20px; background-color: #f5f5f5; }}
                    .container {{ max-width: 600px; margin: 0 auto; background-color: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); text-align: center; }}
                    .success-icon {{ font-size: 48px; color: #28a745; margin-bottom: 20px; }}
                    .success-message {{ background-color: #d4edda; color: #155724; padding: 20px; border-radius: 8px; border: 1px solid #c3e6cb; }}
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="success-icon">✅</div>
                    <h2>📋 RFP Opportunities Due Within 3 Days</h2>
                    <p style="font-size: 16px; color: #666; margin-bottom: 20px;">Date: {today}</p>
                    <div class="success-message">
                        <h3 style="margin-top: 0; color: #155724;">✅ No Upcoming Deadlines!</h3>
                        <p style="margin-bottom: 0; color: #155724;">There are no RFP opportunities due within the next 3 days.</p>
                    </div>
                    <div class="footer" style="margin-top: 20px;">
                        <p><strong>Last updated:</strong> {today}, {current_time} IST</p>
                    </div>
                </div>
            </body>
            </html>
            """
        
        # Attach HTML content
        msg.attach(MIMEText(html_content, 'html'))
        
        # Send email
        server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
        server.starttls()
        server.login(sender_email, sender_password)
        text = msg.as_string()
        server.sendmail(sender_email, recipient_email, text)
        server.quit()
        
        print(f"✅ Email notification sent successfully to {recipient_email}")
        print(f"   📧 RFP opportunities included: {len(due_tasks)}")
        return True
        
    except Exception as e:
        print(f"❌ Error sending email notification: {e}")
        return False

def scheduled_email_notification():
    """Scheduled function to send daily email notification - FIXED VERSION"""
    print(f"\n⏰ Running scheduled email notification at {datetime.now()}")
    print("="*60)
    
    # Get RFP tasks due within 3 days
    due_tasks = get_rfps_due_within_days(3)
    
    print(f"📋 Processing {len(due_tasks)} RFP opportunities for email notification")
    
    # Send email notification
    if send_email_notification(due_tasks):
        print("✅ Daily email notification completed successfully")
    else:
        print("❌ Failed to send daily email notification")
    
    print("="*60)

def schedule_daily_email():
    """Schedule the daily email notification at 6:30 PM"""
    # Schedule the email notification at 6:30 PM daily
    schedule.every().day.at("18:30").do(scheduled_email_notification)
    
    print("📧 Email scheduler started")
    print("   ⏰ Daily notifications scheduled at 6:30 PM")
    print("   📧 Recipient:", EMAIL_RECIPIENT)
    print("   📋 Report: RFP Opportunities Due Within 3 Days")
    print("   🔄 Running scheduler in background...")
    
    # Run the scheduler in a separate thread
    def run_scheduler():
        while True:
            schedule.run_pending()
            time.sleep(60)  # Check every minute
    
    scheduler_thread = threading.Thread(target=run_scheduler, daemon=True)
    scheduler_thread.start()
    
    return scheduler_thread

# =============================================================================
# MAIN EXECUTION - FIXED VERSION
# =============================================================================

def main():
    """Main function to run the complete RFP synchronization and email notification"""
    print("🚀 Starting RFP Synchronization and Email Notification System")
    print("="*80)
    
    # Start the email scheduler
    schedule_daily_email()
    
    # Run the main RFP synchronization
    try:
        # Create RFP tasks from Supabase
        created_tasks = create_rfp_tasks_from_supabase()
        
        # Display summary
        display_summary(created_tasks)
        
        # Verify tasks in Odoo
        verify_tasks_in_odoo()
        
        # Get RFP tasks due within 3 days and send immediate email notification
        print("\n" + "="*80)
        print("📧 SENDING IMMEDIATE EMAIL NOTIFICATION")
        print("="*80)
        
        due_tasks = get_rfps_due_within_days(3)
        send_email_notification(due_tasks)
        
        print("\n✅ System is running! Email notifications will be sent daily at 6:30 PM")
        print("💡 The system will continue running in the background")
        print("📋 Report: RFP Opportunities Due Within 3 Days")
        print("⏰ Next scheduled email: Today at 6:30 PM")
        print("\n🔄 To stop the system, press Ctrl+C")
        
        # Keep the main thread alive
        while True:
            time.sleep(3600)  # Sleep for 1 hour
            
    except KeyboardInterrupt:
        print("\n🛑 System stopped by user")
    except Exception as e:
        print(f"\n❌ System error: {e}")

if __name__ == "__main__":
    main()